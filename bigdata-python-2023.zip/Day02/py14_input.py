val = input('살고 있는 지역을 입력하세요 > ')

print(f'당신은 {val}에 살고 있습니다.')


val = input('이름을 입력하세요 > ')
print(f'당신의 이름은 {val}입니다.')