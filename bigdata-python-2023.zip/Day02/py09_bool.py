# 불린

a = True
b = False 

print(a == b)
print( 10 > 3)

print(int(True)) # True == 1
print(int(False)) # False == 0

print(bool(0)) # 0 이외에는 모두 True
print(bool(1))
print(bool(5))