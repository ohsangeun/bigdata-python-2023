# 다중 입력

x, y = input('두 개 수를 입력하세요.(구분자 ,) > ').split(',')
print(x)
print(y)

x, y = map(int, input('두 개 수를 입력하세요.(구분자 ,) > ').split(',')) # 숫자만 가능

print(x)
print(y)
print(x+y)
