#모듈 사용
#import datetime as dt
from datetime import datetime
from os import getcwd

curr_date = datetime.now() #dt.datetime.now()
print(curr_date)