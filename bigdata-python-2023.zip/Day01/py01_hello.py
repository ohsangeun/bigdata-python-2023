# 주석
# 여러 줄 주석 X

print("Life is short, You need Python!")
print('Hello, Python')